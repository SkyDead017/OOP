﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace AV1
{
    public partial class MainForm : Form
    {
        private int[,] map;
        private List<Thread> scoutThreads = new List<Thread>();
        private Random rand = new Random();
        private int targetsFound = 0;
        private int totalTargets = 0;
        private Point startPoint = Point.Empty;
        private bool mapGenerated = false;
        private volatile bool stopThreads = false;
        private object locker = new object();
        public MainForm()
        {
            InitializeComponent();
            mapPanel.BringToFront();
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            // Очищаем предыдущие данные
            StopAllScouts();
            mapPanel.Controls.Clear();
            logTextBox.Clear();
            targetsFound = 0;
            startPoint = Point.Empty;
            mapGenerated = false;

            // Получаем размер карты
            if (!int.TryParse(txtMapSize.Text, out int mapSize) || mapSize < 5 || mapSize > 20)
            {
                MessageBox.Show("Введите размер карты от 5 до 20");
                return;
            }

            // Рассчитываем количество целей
            totalTargets = Math.Max(1, (int)(mapSize * mapSize * 0.15)); // минимум 1 цель
            map = GenerateMap(mapSize, totalTargets);

            // Отображаем карту
            DrawMap();
            mapGenerated = true;

            // Активируем кнопку запуска разведчиков
            btnStartScouts.Enabled = false;
            UpdateLog($"Карта {mapSize}x{mapSize} сгенерирована. Выберите стартовую точку.");
        }

        private void MapPanel_MouseClick(object sender, MouseEventArgs e)
        {
            if (!mapGenerated || map == null) return;
            int cellSize = mapPanel.Width / map.GetLength(0);
            int x = e.X / cellSize;
            int y = e.Y / cellSize;
            if (x >= 0 && x < map.GetLength(0) && y >= 0 && y < map.GetLength(1))
            {
                startPoint = new Point(x, y);
                UpdateLog($"Установлена стартовая точка: [{x},{y}]");
                DrawMap();
                btnStartScouts.Enabled = true;
            }
            UpdateLog("Красный - найденная цель Розовый - 1 разведчик Синий - 2 разведчик " +
                "Зеленый - 3 разведчик Оранжевый - 4 разведчик\t");
        }

        private void BtnStartScouts_Click(object sender, EventArgs e)
        {
            if (!mapGenerated)
            {
                MessageBox.Show("Сначала сгенерируйте карту!");
                return;
            }

            if (startPoint == Point.Empty)
            {
                MessageBox.Show("Выберите стартовую точку на карте!");
                return;
            }

            StopAllScouts();
            targetsFound = 0;
            UpdateStatus();

            int scoutCount = 4;
            Random rnd = new Random();

            for (int i = 0; i < scoutCount; i++)
            {
                int scoutId = i + 1;

                // Создаем и запускаем поток разведчика
                var thread = new Thread(() => ScoutThreadProc(startPoint.X, startPoint.Y, scoutId, rnd))
                {
                    IsBackground = true
                };
                scoutThreads.Add(thread);
                thread.Start();
            }
        }

        private void ScoutThreadProc(int startX, int startY, int scoutId, Random rnd)
        {
            int x = startX;
            int y = startY;
            int mapSize = map.GetLength(0);

            lock (locker)
            {
                if (map[x, y] == 1)
                {
                    map[x, y] = 0;
                    targetsFound++;
                    UpdateLog($"Разведчик {scoutId} обнаружил цель в [{x},{y}]");
                    UpdateCellColor(x, y, Color.Red);
                    UpdateStatus();
                }
            }

            while (!stopThreads)
            {
                int move = rnd.Next(4);
                Color scoutColor = GetScoutColor(scoutId);
                ColorCellIfNotRed(x, y, scoutColor);

                switch (move)
                {
                    case 0: x++; break;
                    case 1: x--; break;
                    case 2: y++; break;
                    case 3: y--; break;
                }

                if (x < 0 || x >= mapSize || y < 0 || y >= mapSize)
                {
                    UpdateLog($"Разведчик {scoutId} достиг границы в [{x},{y}]");
                    return;
                }

                lock (locker)
                {
                    if (map[x, y] == 1)
                    {
                        map[x, y] = 0;
                        targetsFound++;
                        UpdateLog($"Разведчик {scoutId} обнаружил цель в [{x},{y}]");
                        UpdateCellColor(x, y, Color.Red);
                        UpdateStatus();
                    }
                }

                Thread.Sleep(300);
            }
        }

        private void StopAllScouts()
        {
            stopThreads = true;

            foreach (var thread in scoutThreads)
            {
                if (thread.IsAlive)
                    thread.Join(100);
            }
            scoutThreads.Clear();
            stopThreads = false;
        }
        private Color GetScoutColor(int scoutId)
        {
            Color[] colors = { Color.Violet, Color.Blue, Color.Green, Color.Orange };
            return colors[scoutId % colors.Length];
        }
        private Point GetCellCenter(int x, int y)
        {
            int cellSize = mapPanel.Width / map.GetLength(0);
            return new Point(x * cellSize + cellSize / 2 - 10, y * cellSize + cellSize / 2 - 10);
        }

        private void ColorCellIfNotRed(int x, int y, Color newColor)
        {
            if (mapPanel.InvokeRequired)
            {
                mapPanel.Invoke(new Action(() => ColorCellIfNotRed(x, y, newColor)));
                return;
            }

            foreach (Control control in mapPanel.Controls)
            {
                if (control is Panel cell && (string)control.Tag == $"{x},{y}")
                {
                    // Проверяем, что текущий цвет не красный
                    if (cell.BackColor != Color.Red)
                    {
                        cell.BackColor = newColor;
                    }
                    break;
                }
            }
        }
        private void UpdateCellColor(int x, int y, Color color)
        {
            if (mapPanel.InvokeRequired)
            {
                mapPanel.Invoke(new Action(() => UpdateCellColor(x, y, color)));
                return;
            }

            foreach (Control control in mapPanel.Controls)
            {
                if (control is Panel cell && (string)control.Tag == $"{x},{y}")
                {
                    cell.BackColor = color;
                    break;
                }
            }
        }

        private void UpdateLog(string message)
        {
            if (logTextBox.InvokeRequired)
            {
                logTextBox.Invoke(new Action(() => UpdateLog(message)));
                return;
            }

            logTextBox.AppendText(message + Environment.NewLine);
            logTextBox.ScrollToCaret();
        }

        private void UpdateStatus()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(UpdateStatus));
                return;
            }

            this.Text = $"Авиаразведка - Найдено целей: {targetsFound}/{totalTargets}";
        }

        private int[,] GenerateMap(int size, int targetCount)
        {
            int[,] newMap = new int[size, size];

            for (int i = 0; i < targetCount; i++)
            {
                int x, y;
                do
                {
                    x = rand.Next(size);
                    y = rand.Next(size);
                } while (newMap[x, y] == 1);

                newMap[x, y] = 1;
            }

            return newMap;
        }

        private void DrawMap()
        {
            mapPanel.Controls.Clear();

            if (map == null) return;

            int cellSize = mapPanel.Width / map.GetLength(0);

            for (int y = 0; y < map.GetLength(1); y++)
            {
                for (int x = 0; x < map.GetLength(0); x++)
                {
                    var cell = new Panel
                    {
                        Size = new Size(cellSize, cellSize),
                        Location = new Point(x * cellSize, y * cellSize),
                        BorderStyle = BorderStyle.FixedSingle,
                        BackColor = map[x, y] == 1 ? Color.Yellow : Color.White,
                        Tag = $"{x},{y}",
                        Enabled=false
                    };

                    // Помечаем стартовую точку
                    if (startPoint != Point.Empty && x == startPoint.X && y == startPoint.Y)
                    {
                        cell.BackColor = Color.LightGray;
                    }

                    mapPanel.Controls.Add(cell);
                }
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopAllScouts();
        }

        private void logTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void mapPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}