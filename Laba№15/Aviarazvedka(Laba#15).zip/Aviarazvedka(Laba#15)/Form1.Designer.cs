﻿namespace AV1
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.mapPanel = new System.Windows.Forms.Panel();
            this.logTextBox = new System.Windows.Forms.TextBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.btnStartScouts = new System.Windows.Forms.Button();
            this.txtMapSize = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mapPanel
            // 
            this.mapPanel.BackColor = System.Drawing.Color.White;
            this.mapPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mapPanel.Location = new System.Drawing.Point(12, 50);
            this.mapPanel.Name = "mapPanel";
            this.mapPanel.Size = new System.Drawing.Size(400, 400);
            this.mapPanel.TabIndex = 0;
            this.mapPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.mapPanel_Paint);
            this.mapPanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MapPanel_MouseClick);
            // 
            // logTextBox
            // 
            this.logTextBox.Location = new System.Drawing.Point(418, 50);
            this.logTextBox.Multiline = true;
            this.logTextBox.Name = "logTextBox";
            this.logTextBox.ReadOnly = true;
            this.logTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.logTextBox.Size = new System.Drawing.Size(220, 400);
            this.logTextBox.TabIndex = 1;
            this.logTextBox.TextChanged += new System.EventHandler(this.logTextBox_TextChanged);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(12, 12);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(150, 30);
            this.btnGenerate.TabIndex = 2;
            this.btnGenerate.Text = "Сгенерировать карту";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.BtnGenerate_Click);
            // 
            // btnStartScouts
            // 
            this.btnStartScouts.Enabled = false;
            this.btnStartScouts.Location = new System.Drawing.Point(168, 12);
            this.btnStartScouts.Name = "btnStartScouts";
            this.btnStartScouts.Size = new System.Drawing.Size(150, 30);
            this.btnStartScouts.TabIndex = 3;
            this.btnStartScouts.Text = "Запустить разведчиков";
            this.btnStartScouts.UseVisualStyleBackColor = true;
            this.btnStartScouts.Click += new System.EventHandler(this.BtnStartScouts_Click);
            // 
            // txtMapSize
            // 
            this.txtMapSize.Location = new System.Drawing.Point(418, 18);
            this.txtMapSize.Name = "txtMapSize";
            this.txtMapSize.Size = new System.Drawing.Size(50, 22);
            this.txtMapSize.TabIndex = 4;
            this.txtMapSize.Text = "10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(324, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Размер карты:";
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(650, 462);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMapSize);
            this.Controls.Add(this.btnStartScouts);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.logTextBox);
            this.Controls.Add(this.mapPanel);
            this.Name = "MainForm";
            this.Text = "Авиаразведка";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Panel mapPanel;
        private System.Windows.Forms.TextBox logTextBox;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button btnStartScouts;
        private System.Windows.Forms.TextBox txtMapSize;
        private System.Windows.Forms.Label label1;
    }
}