﻿using System;
using ProductionLib;
using LabOOP13_EventHandler.NewCollection;
using LabOOP13_EventHandler.Journals;


namespace Laba_13_OOP_
{
    public class Program
    {
        static void Main()
        {
            var collection = new MyNewHashTable(5);
            collection.Name = "MyCollection";
            var journal1 = new Journal();
            var journal2 = new Journal();
            collection.CollectionCountChanged += OnEventCountJ1;
            collection.CollectionReferenceChanged += OnEventReferenceJ1;

            collection.Add("iop", new Production("Одежда", 200));
            collection.Add("pop", new  Production("Обувь", 500));
            collection.Remove("iop");
            collection["pop"] = new Production("Костюмы", 1111);
            Console.WriteLine("Журнал 1");
            journal1.GetEntries();

            var collection2 = new MyNewHashTable(5);
            collection2.Name = "MyCollectionTwo";
            collection2.CollectionCountChanged += OnEventCountJ2;
            collection2.CollectionReferenceChanged += OnEventReferenceJ2;
            collection2.Add("iop", new Production("Костюмы", 222));
            collection2.Add("pop", new Production("Ремни", 555));
            collection2.Remove("iop");
            collection2["pop"] = new Production("Одежда", 777);
            Console.WriteLine("Журнал 2");
            journal2.GetEntries();

            void OnEventCountJ1(object source, CollectionHandlerEventArgs args)
            {
                journal1.AddLog(args.Name, args.Action, args.ObjectInfo);
            }

            void OnEventReferenceJ1(object source, CollectionHandlerEventArgs args)
            {
                journal1.AddLog(args.Name, args.Action, args.ObjectInfo);
            }
            void OnEventCountJ2(object source, CollectionHandlerEventArgs args)
            {
                journal2.AddLog(args.Name, args.Action, args.ObjectInfo);
            }

            void OnEventReferenceJ2(object source, CollectionHandlerEventArgs args)
            {
                journal2.AddLog(args.Name, args.Action, args.ObjectInfo);
            }
        }
    }
}
