﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductionLib;
namespace Laba_14_OOP_
{
    public class LabaWork
    {
        public static void WhereExtension(SortedDictionary<int, List<Production>> productions)
        {
            foreach (var listProd in productions)
            {
                foreach (var item in listProd.Value.Where(prod => prod.CountProd > 100000))
                {
                    Console.WriteLine(item.ToString());
                }
            }
        }
        public static void LinqWhere(SortedDictionary<int, List<Production>> productions)
        {
            foreach (var listProd in productions)
            {
                var linq = from prod in listProd.Value
                           where prod.CountProd > 100000
                           select prod;

                foreach (var item in linq)
                {
                    Console.WriteLine(item.ToString());
                }
            }
        }
        public static void GroupExtension(SortedDictionary<int, List<Production>> productions)
        {
            foreach (var item in productions.SelectMany(list => list.Value).GroupBy(pair => pair.Type))
            {
                Console.WriteLine(item.Key + " " + item.Count());

                foreach (var item1 in item)
                {
                    Console.WriteLine(item1);
                }
                Console.WriteLine();
            }
        }

        public static void LinqGroup(SortedDictionary<int, List<Production>> productions)
        {
            var item = from listProd in productions
                      from pair in listProd.Value
                      group pair by pair.Type;

            foreach (var item1 in item)
            {
                Console.WriteLine(item1.Key);
                foreach (var item2 in item1)
                {
                    Console.WriteLine(item2.ToString());
                }
            }
        }
        public static void LinqLet(SortedDictionary<int, List<Production>> productions)
        {
            var population = from listProd in productions
                             from pair in listProd.Value
                             let multiplyCountProd = pair.CountProd * 2
                             select new
                             {
                                 Type = pair.Type,
                                 CountProd = multiplyCountProd
                             };

            foreach (var item in population)
            {
                Console.WriteLine($"Тип продукции:{item.Type}, Количество продукции:{item.CountProd}");
            }
        }
        public static void JoinExtension(SortedDictionary<int, List<Production>> productions, SortedDictionary<int, List<Production>> secondProductions)
        {
            var item = productions.SelectMany(list => list.Value);

            var secondItem = secondProductions.SelectMany(list => list.Value);

            var joinItem = item.Join(secondItem, p1 => p1.Type,
                                        p2 => p2.Type,
                                        (p1, p2) => new { p1, p2 });

            foreach (var result in joinItem)
            {
                Console.WriteLine($"Тип продукции 1: {result.p1.Type}, Количество продукции: {result.p1.CountProd}\t| Тип продукции 2: {result.p2.Type}, Количество продукции: {result.p2.CountProd}");
            }
        }
        public static void JoinLinq(SortedDictionary<int, List<Production>> productions, SortedDictionary<int, List<Production>> secondProductions)
        {
            var item = from listProd in productions
                       from value in listProd.Value
                       select value;

            var secondItem = from listProd in secondProductions
                             from value in listProd.Value
                             select value;

            var joinItem = from pair in item
                           join secondPair in secondItem
                           on pair.Type equals secondPair.Type
                           select new { pair, secondPair };

            foreach (var result in joinItem)
            {
                Console.WriteLine($"Тип продукции 1: {result.pair}, Тип продукции 2: {result.secondPair}");
            }
        }

        public static void UnionExtension(SortedDictionary<int, List<Production>> productions, SortedDictionary<int, List<Production>> secondProductions)
        {
            var item = productions.SelectMany(list => list.Value);
            var secondItem = secondProductions.SelectMany(list => list.Value);
            var unionItem = secondItem.Union(item);

            int i = 1;
            foreach (var result in unionItem)
            {
                Console.WriteLine($"{i}. " + result);
                ++i;
            }
        }
        public static void UnionLinq(SortedDictionary<int, List<Production>> productions, SortedDictionary<int, List<Production>> secondProductions)
        {
            var item = from listProd in productions
                       from value in listProd.Value
                       select value;

            var secondItem = from listProd in secondProductions
                             from value in listProd.Value
                             select value;

            var unionItem = secondItem.Union(item);

            int i = 1;
            foreach (var result in unionItem)
            {
                Console.WriteLine($"{i}. " + result);
                ++i;
            }
        }

    }
}
