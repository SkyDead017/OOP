﻿using ProductionLib;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba_12.Collection;

namespace Laba_14_OOP_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SortedDictionary<int, List<Production>> productions = new SortedDictionary<int, List<Production>>();

            for (int i = 0; i < 10; i++)
            {
                var item = new Production();
                item.RandInit();
                var list = new List<Production>();
                list.Add(item);
                productions.Add(i, list);
            }
            SortedDictionary<int, List<Production>> secondProductions = new SortedDictionary<int, List<Production>>();

            for (int i = 0; i < 10; i++)
            {
                var item = new Production();
                item.RandInit();
                var list = new List<Production>();
                list.Add(item);
                secondProductions.Add(i, list);
            }

            Stopwatch sw = new Stopwatch();


            long timeLinq = 0, timeExtension = 0, timeFor = 0;
            for (int i = 0; i < 5; i++)
            {
                sw.Restart();
                LabaWork.LinqWhere(productions);
                Console.Clear();
                sw.Stop();
                timeLinq += sw.ElapsedTicks;
            }

            for (int i = 0; i < 5; i++)
            {
                sw.Restart();
                LabaWork.WhereExtension(productions);
                Console.Clear();
                sw.Stop();
                timeExtension += sw.ElapsedTicks;
            }



            List<Production> newProductions = new List<Production>();
            for (int i = 0; i < 5; i++)
            {
                sw.Restart();
                for (int j = 0; j < productions[i].Count; ++j)
                {
                    foreach (var item in productions[i])
                    {
                        if (item.CountProd > 100000)
                        {
                            newProductions.Add(item);
                        }
                    }
                    timeFor += sw.ElapsedTicks;
                }

            }

            Console.WriteLine("Время выполнения метода расширения: " + timeExtension / 5
                + "\nВремя выполнения запроса: " + timeLinq / 5
                + "\nВремя выполнения цикла: " + timeFor / 5
                );

            Console.WriteLine("\nВыполнение метода Where\n");
            LabaWork.WhereExtension(productions);

            Console.WriteLine("\nВыполнение метода GroupBy\n");
            LabaWork.GroupExtension(productions);

            Console.WriteLine("\nВыполнение метода Union\n");
            LabaWork.UnionExtension(productions, secondProductions);

            Console.WriteLine("\nВыполнение метода Join\n");
            LabaWork.JoinExtension(productions, secondProductions);

            Console.WriteLine("\nИспользование Let\n");
            LabaWork.LinqLet(productions);

            Console.WriteLine("\nПрименение методов расширения HashTable\n");
            HashTable<string, Production> table = new HashTable<string, Production>(100);
            Console.WriteLine("ХЕШ-ТАБЛИЦА:");
            for (int i = 0; i < 5; ++i)
            {
                Production production = new Production();
                production.RandInit();
                table.Add($"{i + 1}", production);
                Console.WriteLine(production);
            }

            Console.WriteLine("\nВыполнение метода Where\n");
            var whereResult = table.Where_(item => item.Value.Type=="Обувь");
            foreach (var result in whereResult)
            {
                Console.WriteLine(result.Key + " " + result.Value);
            }

            Console.WriteLine("\nВыполнение метода OrderByDecrease\n");
            var orderResult = table.OrderByDecrease_(item => item.Value.Type);
            foreach (var result in orderResult)
            {
                Console.WriteLine(result.Key + " " + result.Value);
            }

            Console.WriteLine("\nВыполнение метода Max\n");
            var maxValue = table.Max_(item => item.Value.CountProd);
            var itemsWithMaxValue = table.Where_(item => item.Value.CountProd == maxValue);

            foreach (var item in itemsWithMaxValue)
            {
                Console.WriteLine($"Ключ: {item.Key}, Значение: {item.Value}");
            }
        }
    }
}
