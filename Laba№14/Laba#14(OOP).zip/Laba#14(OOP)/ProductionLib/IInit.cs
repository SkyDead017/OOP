﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductionLib
{
    public interface IInit
    {
        void Init();
        void RandInit();
    }
}
