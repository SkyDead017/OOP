﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductionLib;
namespace Laba_12.Collection
{
    public static class Extensions
    {
        public static IEnumerable<ItemHT<TKey, TValue>> Where_<TKey, TValue>(this HashTable<TKey, TValue> myHashTable, Func<ItemHT<TKey, TValue>, bool> predicate)
        {
            foreach(var item in myHashTable)
            {
                if (predicate(item))
                {
                    yield return item;
                }
            }
        }
        public static int Max_<TKey,TValue>(this HashTable<TKey, TValue> myHashTable, Func<ItemHT<TKey, TValue>, int> selector)
        {
            int max = int.MinValue;
            foreach (var item in myHashTable)
            {
                int current = selector(item);
                if (max < current)
                {
                    max = current;
                }
            }
            return max;
        }
        public static IEnumerable<ItemHT<TKey, TValue>> OrderByIncrease_<TKey, TValue, TKeySort>(
            this HashTable<TKey, TValue> collection,
            Func<ItemHT<TKey, TValue>, TKeySort> keySelector)
            where TKeySort : IComparable<TKeySort> 
        {
            var items = new List<ItemHT<TKey, TValue>>(collection);

            items.Sort((x, y) =>
            {
                var xKey = keySelector(x);
                var yKey = keySelector(y);
                return xKey.CompareTo(yKey);
            });

            return items;
        }
        public static IEnumerable<ItemHT<TKey, TValue>> OrderByDecrease_<TKey, TValue, TKeySort>(
            this HashTable<TKey, TValue> collection,
            Func<ItemHT<TKey, TValue>, TKeySort> keySelector)
            where TKeySort : IComparable<TKeySort>
        {
            var items = new List<ItemHT<TKey, TValue>>(collection);

            items.Sort((x, y) =>
            {
                var xKey = keySelector(x);
                var yKey = keySelector(y);
                return yKey.CompareTo(xKey);
            });

            return items;
        }
    }
}
