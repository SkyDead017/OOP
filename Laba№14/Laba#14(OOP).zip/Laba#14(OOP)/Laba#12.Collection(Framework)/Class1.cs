﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba_12.Collection_Framework_
{
    public class Class1
    {
    }
}
