﻿using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laba_12.Collection;
using System.Collections;

namespace Laba_13.Library
{
    public delegate void CollectionHandler(object source, CollectionHandlerEventArgs args);
    public class CollectionHandlerEventArgs:EventArgs
    {
        public string Name {  get; set; }
        public string Action {  get; set; }
        public object ObjectInfo {  get; set; }
        public CollectionHandlerEventArgs(string name, string action, object objectInfo)
        {
            Name = name;
            Action = action;
            ObjectInfo = objectInfo;
        }
        public override string ToString()
        {
            return $"Название: {Name}, Действие: {Action}, Ссылка на объект: {ObjectInfo.ToString()}";
        }
    }
    public class MyNewHashTable<TKey, TValue>:HashTable<TKey,TValue>
    {
        public event CollectionHandler CollectionCountChanged;
        public event CollectionHandler CollectionReferenceChanged;
        public MyNewHashTable()
        {
            _capacity = 0;
            _tables = new ItemHT<TKey, TValue>[_capacity];
        }
        public MyNewHashTable(int capacity)
        {
            _capacity = capacity;
            _tables = new ItemHT<TKey, TValue>[capacity];
        }
        public string Name { get; set; }
        public new void Add(TKey key, TValue value)
        {
            var item = new ItemHT<TKey, TValue>(key, value);
            base.Add(key, value);
            CollectionCountChanged?.Invoke(this, new CollectionHandlerEventArgs(Name, "Элемент добавлен", item));
        }
        public new bool Remove(TKey key)
        {
            var item = SearchKey(key);
            bool result = base.Remove(key);
            CollectionCountChanged?.Invoke(this, new CollectionHandlerEventArgs(Name, "Элемент удален", item));
            return result;
        }
        public void Update(TKey key, TValue newValue)
        {
            if (key == null)
                throw new ArgumentNullException(nameof(key));
            if (this.ContainsKey(key))
            {
                var item = this.SearchKey(key);
                item.Value = newValue;
                CollectionReferenceChanged?.Invoke(this, new CollectionHandlerEventArgs(
                Name, "Элемент перезаписан", item
            ));
            }
        }

        public new TValue this[TKey key]
        {
            set
            {
                Update(key, value);
            }
            get
            {
                if (this.ContainsKey(key))
                {
                    return this.SearchKey(key).Value;
                }
                throw new KeyNotFoundException($"Ключ '{key}' не найден.");
            }
        }
    }
}
