﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba_13.Library
{
    public class Journal
    {
        private List<JournalEntry> _entries;

        public Journal()
        {
            _entries = new List<JournalEntry>();
        }

        public void AddLog(string name, string action, object obj)
        {
            var entry = new JournalEntry(name, action, obj);
            _entries.Add(entry);
        }

        public void GetEntries()
        {
            foreach (var entry in _entries)
            {
                Console.WriteLine(entry.ToString());
            }
        }
    }
}
