﻿namespace Laba_16_Form_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AddElementButton = new Button();
            AddElementTextBox = new TextBox();
            SearchElementButton = new Button();
            SearchElementTextBox = new TextBox();
            DeleteElementButton = new Button();
            DeleteElementTextBox = new TextBox();
            UpdateElementButton = new Button();
            SortCollectionButton = new Button();
            SortElementComboBox = new ComboBox();
            label1 = new Label();
            MinElementButton = new Button();
            AverageButton = new Button();
            CountWorkerButton = new Button();
            richTextBox1 = new RichTextBox();
            CreateCollectionTextBox = new TextBox();
            CreateCollectionButton = new Button();
            PrintCollectionButton = new Button();
            label2 = new Label();
            TypeFileComboBox = new ComboBox();
            SerializerButton = new Button();
            ReadFileButton = new Button();
            SuspendLayout();
            // 
            // AddElementButton
            // 
            AddElementButton.Location = new Point(12, 49);
            AddElementButton.Name = "AddElementButton";
            AddElementButton.Size = new Size(165, 34);
            AddElementButton.TabIndex = 2;
            AddElementButton.Text = "Добавить элементы";
            AddElementButton.UseVisualStyleBackColor = true;
            AddElementButton.Click += AddElementButton_Click;
            // 
            // AddElementTextBox
            // 
            AddElementTextBox.Location = new Point(184, 56);
            AddElementTextBox.Name = "AddElementTextBox";
            AddElementTextBox.PlaceholderText = "Количество элементов";
            AddElementTextBox.Size = new Size(173, 27);
            AddElementTextBox.TabIndex = 3;
            AddElementTextBox.TextAlign = HorizontalAlignment.Center;
            AddElementTextBox.TextChanged += AddElementTextBox_TextChanged;
            // 
            // SearchElementButton
            // 
            SearchElementButton.Location = new Point(12, 95);
            SearchElementButton.Name = "SearchElementButton";
            SearchElementButton.Size = new Size(165, 34);
            SearchElementButton.TabIndex = 4;
            SearchElementButton.Text = "Поиск элемента";
            SearchElementButton.UseVisualStyleBackColor = true;
            SearchElementButton.Click += SearchElementButton_Click;
            // 
            // SearchElementTextBox
            // 
            SearchElementTextBox.Location = new Point(184, 102);
            SearchElementTextBox.Name = "SearchElementTextBox";
            SearchElementTextBox.PlaceholderText = "Ключ элемента";
            SearchElementTextBox.Size = new Size(173, 27);
            SearchElementTextBox.TabIndex = 5;
            SearchElementTextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // DeleteElementButton
            // 
            DeleteElementButton.Location = new Point(12, 141);
            DeleteElementButton.Name = "DeleteElementButton";
            DeleteElementButton.Size = new Size(165, 34);
            DeleteElementButton.TabIndex = 6;
            DeleteElementButton.Text = "Удалить элемент";
            DeleteElementButton.UseVisualStyleBackColor = true;
            DeleteElementButton.Click += DeleteElementButton_Click;
            // 
            // DeleteElementTextBox
            // 
            DeleteElementTextBox.Location = new Point(184, 148);
            DeleteElementTextBox.Name = "DeleteElementTextBox";
            DeleteElementTextBox.PlaceholderText = "Ключ элемента";
            DeleteElementTextBox.Size = new Size(173, 27);
            DeleteElementTextBox.TabIndex = 7;
            DeleteElementTextBox.TextAlign = HorizontalAlignment.Center;
            DeleteElementTextBox.TextChanged += DeleteElementTextBox_TextChanged;
            // 
            // UpdateElementButton
            // 
            UpdateElementButton.Location = new Point(12, 187);
            UpdateElementButton.Name = "UpdateElementButton";
            UpdateElementButton.Size = new Size(364, 32);
            UpdateElementButton.TabIndex = 8;
            UpdateElementButton.Text = "Редактировать элемент";
            UpdateElementButton.UseVisualStyleBackColor = true;
            // 
            // SortCollectionButton
            // 
            SortCollectionButton.Location = new Point(12, 225);
            SortCollectionButton.Name = "SortCollectionButton";
            SortCollectionButton.Size = new Size(165, 34);
            SortCollectionButton.TabIndex = 9;
            SortCollectionButton.Text = "Сортировать по";
            SortCollectionButton.UseVisualStyleBackColor = true;
            SortCollectionButton.Click += SortCollectionButton_Click;
            // 
            // SortElementComboBox
            // 
            SortElementComboBox.FormattingEnabled = true;
            SortElementComboBox.Items.AddRange(new object[] { "Тип продукции", "Количество продукции" });
            SortElementComboBox.Location = new Point(184, 229);
            SortElementComboBox.Name = "SortElementComboBox";
            SortElementComboBox.Size = new Size(173, 28);
            SortElementComboBox.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 262);
            label1.Name = "label1";
            label1.Size = new Size(70, 20);
            label1.TabIndex = 11;
            label1.Text = "Запросы";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // MinElementButton
            // 
            MinElementButton.Location = new Point(12, 285);
            MinElementButton.Name = "MinElementButton";
            MinElementButton.Size = new Size(165, 29);
            MinElementButton.TabIndex = 12;
            MinElementButton.Text = "Min";
            MinElementButton.UseVisualStyleBackColor = true;
            // 
            // AverageButton
            // 
            AverageButton.Location = new Point(215, 285);
            AverageButton.Name = "AverageButton";
            AverageButton.Size = new Size(161, 29);
            AverageButton.TabIndex = 13;
            AverageButton.Text = "Average";
            AverageButton.UseVisualStyleBackColor = true;
            // 
            // CountWorkerButton
            // 
            CountWorkerButton.Location = new Point(12, 320);
            CountWorkerButton.Name = "CountWorkerButton";
            CountWorkerButton.Size = new Size(364, 32);
            CountWorkerButton.TabIndex = 14;
            CountWorkerButton.Text = "Количество работников в мастерских";
            CountWorkerButton.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(395, 9);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(403, 497);
            richTextBox1.TabIndex = 15;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // CreateCollectionTextBox
            // 
            CreateCollectionTextBox.Location = new Point(184, 12);
            CreateCollectionTextBox.Name = "CreateCollectionTextBox";
            CreateCollectionTextBox.PlaceholderText = "Вместимость коллекции";
            CreateCollectionTextBox.Size = new Size(173, 27);
            CreateCollectionTextBox.TabIndex = 17;
            CreateCollectionTextBox.TextAlign = HorizontalAlignment.Center;
            // 
            // CreateCollectionButton
            // 
            CreateCollectionButton.Location = new Point(12, 5);
            CreateCollectionButton.Name = "CreateCollectionButton";
            CreateCollectionButton.Size = new Size(165, 34);
            CreateCollectionButton.TabIndex = 16;
            CreateCollectionButton.Text = "Создать коллекцию";
            CreateCollectionButton.UseVisualStyleBackColor = true;
            CreateCollectionButton.Click += CreateCollectionButton_Click;
            // 
            // PrintCollectionButton
            // 
            PrintCollectionButton.Location = new Point(12, 358);
            PrintCollectionButton.Name = "PrintCollectionButton";
            PrintCollectionButton.Size = new Size(191, 29);
            PrintCollectionButton.TabIndex = 18;
            PrintCollectionButton.Text = "Напечатать коллекцию";
            PrintCollectionButton.UseVisualStyleBackColor = true;
            PrintCollectionButton.Click += PrintCollectionButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 394);
            label2.Name = "label2";
            label2.Size = new Size(85, 20);
            label2.TabIndex = 19;
            label2.Text = "Тип файла:";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TypeFileComboBox
            // 
            TypeFileComboBox.FormattingEnabled = true;
            TypeFileComboBox.Items.AddRange(new object[] { "Бинарный файл", "JSON", "XML" });
            TypeFileComboBox.Location = new Point(103, 393);
            TypeFileComboBox.Name = "TypeFileComboBox";
            TypeFileComboBox.Size = new Size(173, 28);
            TypeFileComboBox.TabIndex = 20;
            TypeFileComboBox.SelectedIndexChanged += TypeFileComboBox_SelectedIndexChanged;
            // 
            // SerializerButton
            // 
            SerializerButton.Location = new Point(12, 427);
            SerializerButton.Name = "SerializerButton";
            SerializerButton.Size = new Size(165, 29);
            SerializerButton.TabIndex = 21;
            SerializerButton.Text = "Сериализовать";
            SerializerButton.UseVisualStyleBackColor = true;
            SerializerButton.Click += SerializerButton_Click;
            // 
            // ReadFileButton
            // 
            ReadFileButton.Location = new Point(211, 427);
            ReadFileButton.Name = "ReadFileButton";
            ReadFileButton.Size = new Size(165, 29);
            ReadFileButton.TabIndex = 22;
            ReadFileButton.Text = "Десериализовать";
            ReadFileButton.UseVisualStyleBackColor = true;
            ReadFileButton.Click += ReadFileButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 512);
            Controls.Add(ReadFileButton);
            Controls.Add(SerializerButton);
            Controls.Add(TypeFileComboBox);
            Controls.Add(label2);
            Controls.Add(PrintCollectionButton);
            Controls.Add(CreateCollectionTextBox);
            Controls.Add(CreateCollectionButton);
            Controls.Add(richTextBox1);
            Controls.Add(CountWorkerButton);
            Controls.Add(AverageButton);
            Controls.Add(MinElementButton);
            Controls.Add(label1);
            Controls.Add(SortElementComboBox);
            Controls.Add(SortCollectionButton);
            Controls.Add(UpdateElementButton);
            Controls.Add(DeleteElementTextBox);
            Controls.Add(DeleteElementButton);
            Controls.Add(SearchElementTextBox);
            Controls.Add(SearchElementButton);
            Controls.Add(AddElementTextBox);
            Controls.Add(AddElementButton);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button AddElementButton;
        private TextBox AddElementTextBox;
        private Button SearchElementButton;
        private TextBox SearchElementTextBox;
        private Button DeleteElementButton;
        private TextBox DeleteElementTextBox;
        private Button UpdateElementButton;
        private Button SortCollectionButton;
        private ComboBox SortElementComboBox;
        private Label label1;
        private Button MinElementButton;
        private Button AverageButton;
        private Button CountWorkerButton;
        private RichTextBox richTextBox1;
        private TextBox CreateCollectionTextBox;
        private Button CreateCollectionButton;
        private Button PrintCollectionButton;
        private Label label2;
        private ComboBox TypeFileComboBox;
        private Button SerializerButton;
        private Button ReadFileButton;
    }
}
