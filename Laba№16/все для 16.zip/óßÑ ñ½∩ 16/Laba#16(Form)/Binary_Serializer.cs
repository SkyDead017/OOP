﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Laba_16_OOP_
{

    internal class Binary_Serializer : IFileSerializer
    {
        private readonly Encoding _encoding = Encoding.UTF8;

        public T Deserialize<T>(string path)
        {
            try
            {
                using (var stream = File.Open(path, FileMode.Open))
                using (var reader = new BinaryReader(stream, _encoding))
                {
                    if (stream.Length < sizeof(int))
                        throw new InvalidDataException("Файл повреждён (слишком мал)");

                    int count = reader.ReadInt32();
                    var table = new HashTable<string, Production>(capacity: count > 0 ? count : 10);

                    for (int i = 0; i < count; i++)
                    {
                        string key = ReadNullableString(reader);
                        string typeName = ReadNullableString(reader);
                        string type = ReadNullableString(reader);
                        int countProd = reader.ReadInt32();

                        Production value = typeName switch
                        {
                            "ProductionLibrary.Production" => new Production(type, countProd),
                            "ProductionLibrary.Factory" => new Factory(type, countProd, reader.ReadInt32()),
                            "ProductionLibrary.Department" => new Department(type, countProd,
                                reader.ReadInt32(), ReadNullableString(reader)),
                            "ProductionLibrary.WorkShop" => new WorkShop(type, countProd,
                                reader.ReadInt32(), ReadNullableString(reader), reader.ReadInt32()),
                            _ => throw new InvalidDataException($"Неизвестный тип: {typeName}")
                        };

                        table.Add(key, value);
                    }

                    return (T)(object)table;
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Ошибка чтения бинарного файла: {ex.Message}", ex);
            }
        }

        private string ReadNullableString(BinaryReader reader)
        {
            return reader.ReadBoolean() ? reader.ReadString() : null;
        }

        public void Serialize<T>(T obj, string path)
        {
            if (obj is not HashTable<string, Production> table)
                throw new ArgumentException("Ожидается HashTable<string, Production>");

            try
            {
                using (var stream = File.Create(path))
                using (var writer = new BinaryWriter(stream, _encoding))
                {
                    writer.Write(table.Count);

                    foreach (var pair in table)
                    {
                        WriteNullableString(writer, pair.Key);
                        WriteNullableString(writer, pair.Value?.GetType().FullName);
                        WriteNullableString(writer, pair.Value?.Type);
                        writer.Write(pair.Value?.CountProd ?? 0);

                        switch (pair.Value)
                        {
                            case WorkShop ws:
                                writer.Write(ws.CountDepartments);
                                WriteNullableString(writer, ws.TypeDepartment);
                                writer.Write(ws.CountWorker);
                                break;
                            case Department dep:
                                writer.Write(dep.CountDepartments);
                                WriteNullableString(writer, dep.TypeDepartment);
                                break;
                            case Factory fac:
                                writer.Write(fac.CountDepartments);
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Ошибка записи бинарного файла: {ex.Message}", ex);
            }
        }

        private void WriteNullableString(BinaryWriter writer, string value)
        {
            writer.Write(value != null);
            if (value != null) writer.Write(value);
        }
    }
    //internal class Binary_Serializer : IFileSerializer
    //{
    //    private readonly Encoding _encoding = Encoding.UTF8;
    //    public T Deserialize<T>(string path)
    //    {
    //        using (var reader = new BinaryReader(File.Open(path, FileMode.Open), _encoding))
    //        {
    //            if (typeof(T) != typeof(HashTable<string, Production>))
    //                throw new NotSupportedException("Поддерживается только HashTable<string, Production>");

    //            var table = new HashTable<string, Production>();
    //            int count = reader.ReadInt32();

    //            for (int i = 0; i < count; i++)
    //            {
    //                string key = reader.ReadString();
    //                string typeName = reader.ReadString();
    //                string type = reader.ReadString();
    //                int countProd = reader.ReadInt32();

    //                Production value;
    //                if (typeName == typeof(Production).FullName)
    //                {
    //                    value = new Production(type, countProd);
    //                }
    //                else if (typeName == typeof(Factory).FullName)
    //                {
    //                    int countDep = reader.ReadInt32();
    //                    value = new Factory(type, countProd, countDep);
    //                }
    //                else if (typeName == typeof(Department).FullName)
    //                {
    //                    int countDep = reader.ReadInt32();
    //                    string typeDep = reader.ReadString();
    //                    value = new Department(type, countProd, countDep, typeDep);
    //                }
    //                else if (typeName == typeof(WorkShop).FullName)
    //                {
    //                    int countDep = reader.ReadInt32();
    //                    string typeDep = reader.ReadString();
    //                    int countWorker = reader.ReadInt32();
    //                    value = new WorkShop(type, countProd, countDep, typeDep, countWorker);
    //                }
    //                else
    //                {
    //                    throw new NotSupportedException($"Тип {typeName} не поддерживается");
    //                }

    //                table.Add(key, value);
    //            }

    //            return (T)(object)table;
    //        }
    //    }

    //    public void Serialize<T>(T obj, string path)
    //    {
    //        if (obj is not HashTable<string, Production> table)
    //            throw new NotSupportedException("Поддерживается только HashTable<string, Production>");

    //        using (var writer = new BinaryWriter(File.Open(path, FileMode.Create), _encoding))
    //        {
    //            writer.Write(table.Count);

    //            foreach (var pair in table)
    //            {
    //                writer.Write(pair.Key);
    //                writer.Write(pair.Value.GetType().FullName);
    //                writer.Write(pair.Value.Type);
    //                writer.Write(pair.Value.CountProd);

    //                if (pair.Value is Factory itemFac)
    //                {
    //                    writer.Write(itemFac.CountDepartments);
    //                }
    //                else if (pair.Value is Department itemDep)
    //                {
    //                    writer.Write(itemDep.CountDepartments);
    //                    writer.Write(itemDep.TypeDepartment);
    //                }
    //                else if (pair.Value is WorkShop itemWorkShop)
    //                {
    //                    writer.Write(itemWorkShop.CountDepartments);
    //                    writer.Write(itemWorkShop.TypeDepartment);
    //                    writer.Write(itemWorkShop.CountWorker);
    //                }
    //            }
    //        }
    //    }
    //}
}
