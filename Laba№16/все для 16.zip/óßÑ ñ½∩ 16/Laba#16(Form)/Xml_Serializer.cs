﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Laba_16_OOP_
{
    public class XmlFileSerializer : IFileSerializer
    {
        public void Serialize<T>(T obj, string path)
        {
            var serializer = new XmlSerializer(typeof(T), GetExtraTypes());
            using (var writer = new StreamWriter(path))
            {
                serializer.Serialize(writer, obj);
            }
        }

        public T Deserialize<T>(string path)
        {
            var serializer = new XmlSerializer(typeof(T), GetExtraTypes());
            using (var reader = new StreamReader(path))
            {
                return (T)serializer.Deserialize(reader);
            }
        }

        private Type[] GetExtraTypes()
        {
            return new Type[]
            {
            typeof(Production),
            typeof(Factory),
            typeof(Department),
            typeof(WorkShop),
            typeof(HashTable<string, Production>),
            typeof(List<KeyValuePair<string, Production>>),
            typeof(KeyValuePair<string, Production>)
            };
        }
    }

    //public class Xml_Serializer : IFileSerializer
    //{
    //    public T Deserialize<T>(string path)
    //    {
    //        using (var stream = File.Open(path, FileMode.Open))
    //        {
    //            var serializer = new XmlSerializer(typeof(T));
    //            return (T)serializer.Deserialize(stream);
    //        }
    //    }

    //    public void Serialize<T>(T obj, string path)
    //    {
    //        using (var stream = File.Open(path, FileMode.Create))
    //        {
    //            var serializer = new XmlSerializer(typeof(T));
    //            serializer.Serialize(stream, obj);
    //        }
    //    }
    //}
}
