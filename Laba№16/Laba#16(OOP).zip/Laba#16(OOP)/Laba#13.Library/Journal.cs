﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba_13.Library
{
    public class Journal
    {
        private readonly string _logFilePath;
        public string LogFilePath
        {
            get { return _logFilePath; }
        }

        public Journal(string logFilePath)
        {
            _logFilePath = logFilePath;

            File.WriteAllText(_logFilePath, $"Журнал событий - {DateTime.Now}\n\n");
        }

        public void AddLog(string name, string action, object obj)
        {
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] " +
                             $"Коллекция: {name}\n" +
                             $"Действие: {action}\n" +
                             $"Объект: {obj?.ToString() ?? "null"}\n" +
                             "----------------------------------------\n";

            File.AppendAllText(_logFilePath, logEntry);
        }
    }
}
