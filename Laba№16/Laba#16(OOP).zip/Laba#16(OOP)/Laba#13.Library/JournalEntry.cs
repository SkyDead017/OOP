﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba_13.Library
{
    public class JournalEntry
    {
        public string Name { get; set; }

        public string Action { get; set; }

        public object ObjectInfo { get; set; }

        public JournalEntry(string name, string action, object objInfo)
        {
            Name = name;
            Action = action;
            ObjectInfo = objInfo;
        }

        public override string ToString()
        {
            return $"Название коллекции: {Name}\n" +
                $"Действие: {Action}\n" +
                $"Ссылка на объект: [\n{ObjectInfo.ToString()}]\n";
        }
    }
}
