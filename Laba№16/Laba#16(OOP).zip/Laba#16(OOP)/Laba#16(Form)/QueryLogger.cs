﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba_16_Form_
{
    public class QueryLogger
    {
        private readonly string _logFilePath;
        public string LogFilePath
        {
            get { return _logFilePath; }
        }
        public QueryLogger(string logFilePath)
        {
            _logFilePath = logFilePath;
            // Создаем файл при инициализации
            File.WriteAllText(_logFilePath, $"Журнал запросов - {DateTime.Now}\n\n");
        }

        public void LogQuery(string queryType, string result)
        {
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] Запрос: {queryType}\n" +
                             $"Результат:\n{result.ToString()}\n" +
                             new string('-', 50) + "\n";

            File.AppendAllText(_logFilePath, logEntry);
        }
        public void LogQueryList(string queryType, List<ItemHT<string, Production>> result)
        {
            string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] Запрос: {queryType}\n" +
                             $"Результат: ";

            File.AppendAllText(_logFilePath, logEntry);
            foreach (var item in result)
            {
                File.AppendAllText(_logFilePath,$"[{item.ToString()}]\n");
            }
        }
    }
}
