﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Laba_16_OOP_
{
    public class XmlFileSerializer : IFileSerializer
    {
        public void Serialize<T>(T obj, string path)
        {
            var serializer = new XmlSerializer(typeof(T), GetExtraTypes());
            using (var writer = new StreamWriter(path))
            {
                serializer.Serialize(writer, obj);
            }
        }

        //public T Deserialize<T>(string path)
        //{
        //    var serializer = new XmlSerializer(typeof(T));
        //    using (var reader = new StreamReader(path))
        //    {
        //        return (T)serializer.Deserialize(reader);
        //    }
        //}

        private Type[] GetExtraTypes()
        {
            return new Type[]
            {
            typeof(Production),
            typeof(Factory),
            typeof(Department),
            typeof(WorkShop),
            typeof(HashTable<string, Production>),
            typeof(List<KeyValuePair<string, Production>>),
            typeof(KeyValuePair<string, Production>)
            };
        }

        public HashTable<string, Production> Deserialize(string path)
        {
            var serializer = new XmlSerializer(typeof(List<ItemHT<string, Production>>));
            using (var reader = new StreamReader(path))
            {
                var table = new HashTable<string, Production>();

                var list = (List<ItemHT<string, Production>>)serializer.Deserialize(reader);

                for (int i = 0; i < list.Count; i++)
                {
                    table.Add(list[i]);
                }

                return table;
            }
        }
    }
}
