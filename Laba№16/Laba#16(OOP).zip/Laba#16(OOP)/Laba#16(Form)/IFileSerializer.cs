﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba_16_OOP_
{
    public interface IFileSerializer
    {
        public void Serialize<T>(T obj, string path);
        public HashTable<string, Production> Deserialize(string path);
    }
}
