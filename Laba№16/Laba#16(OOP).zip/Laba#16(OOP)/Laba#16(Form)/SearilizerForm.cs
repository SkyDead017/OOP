﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba_16_Form_
{
    public partial class SearilizerForm : Form
    {
        private void SearilizerForm_Load(object sender, EventArgs e)
        {
            
        }
    }
}
