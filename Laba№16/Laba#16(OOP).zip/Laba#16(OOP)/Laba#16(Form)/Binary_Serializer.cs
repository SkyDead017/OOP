﻿using Laba_12.Collection;
using Laba_13.Library;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Laba_16_OOP_
{

    internal class Binary_Serializer : IFileSerializer
    {
        private readonly Encoding _encoding = Encoding.Default;

        public HashTable<string, Production> Deserialize(string path)
        {
            try
            {
                using (var stream = File.Open(path, FileMode.Open))
                using (var reader = new BinaryReader(stream, _encoding))
                {
                    if (stream.Length < sizeof(int))
                        throw new InvalidDataException("Файл повреждён (слишком мал)");

                    string str = "";
                    while (reader.PeekChar() > -1)
                    {
                        str += reader.ReadChar();
                    }

                    var objs = str.Split('\n');

                    HashTable<string, Production> table = new();

                    for (int i = 0; i < objs.Length-1; i++)
                    {
                        var data = objs[i].Split(',');
                        
                        if (data.Length == 3)
                        {
                            ItemHT<string, Production> item = new(data[0], 
                                new Production(data[1], int.Parse(data[2])));
                            table.Add(item);
                        }
                        if (data.Length == 4)
                        {
                            ItemHT<string, Production> item = new(data[0],
                                new Factory(data[1], int.Parse(data[2]), int.Parse(data[3])));
                            table.Add(item);
                        }
                        if (data.Length == 5)
                        {
                            ItemHT<string, Production> item = new(data[0],
                                new Department(data[1], int.Parse(data[2]), int.Parse(data[3]),
                                data[4]));
                            table.Add(item);
                        }
                        if (data.Length == 6)
                        {
                            ItemHT<string, Production> item = new(data[0],
                                new WorkShop(data[1], int.Parse(data[2]), int.Parse(data[3]),
                                data[4], int.Parse(data[5])));
                            table.Add(item);
                        }
                    }

                    return table;
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Ошибка чтения бинарного файла: {ex.Message}", ex);
            }
        }

        private string ReadNullableString(BinaryReader reader)
        {
            return reader.ReadBoolean() ? reader.ReadString() : null;
        }

        public void Serialize<T>(T obj, string path)
        {
            if (obj is not List<ItemHT<string, Production>> table)
                throw new ArgumentException("Ожидается HashTable<string, Production>");

            try
            {
                using BinaryWriter file = new BinaryWriter(new FileStream(path, FileMode.Append));

                List<string> list = new();

                foreach (var item in table)
                {
                    list.Add(item.Key + "," + item.Value.ToStringChar());
                }

                string str = "";
                for (int i = 0; i < list.Count; i++)
                {
                    str += list[i];
                    str += "\n";
                }

                byte[] bytes = Encoding.Default.GetBytes(str);

                file.Write(bytes, 0, bytes.Length);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Ошибка записи бинарного файла: {ex.Message}", ex);
            }
        }

        private void WriteNullableString(BinaryWriter writer, string value)
        {
            writer.Write(value != null);
            if (value != null) writer.Write(value);
        }
    }
}
