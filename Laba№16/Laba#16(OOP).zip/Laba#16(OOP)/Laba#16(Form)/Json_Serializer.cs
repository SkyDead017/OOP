﻿using Laba_12.Collection;
using ProductionLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Laba_16_OOP_
{
    public class JsonFileSerializer : IFileSerializer
    {
        private readonly JsonSerializerOptions _options;

        public JsonFileSerializer()
        {
            _options = new JsonSerializerOptions
            {
                WriteIndented = true,
                Converters = { new ProductionConverter(), new HashTableConverter() }
            };
        }

        //public T Deserialize<T>(string path)
        //{
        //    string json = File.ReadAllText(path);
        //    return JsonSerializer.Deserialize<T>(json, _options);
        //}

        public HashTable<string, Production> Deserialize(string path)
        {
            using FileStream file = new(path, FileMode.Open);

            var obj = JsonSerializer.Deserialize<List<ItemHT<string, Production>>>(file);

            var table = new HashTable<string, Production>();

            foreach (var item in obj)
            {
                table.Add(item);
            }

            return table;
        }

        public void Serialize<T>(T obj, string path)
        {
            using FileStream file = new(path, FileMode.Append);

            JsonSerializer.Serialize(file, obj);
        }

        private class HashTableConverter : JsonConverter<HashTable<string, Production>>
        {
            public override HashTable<string, Production> Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
            {
                var items = JsonSerializer.Deserialize<List<KeyValuePair<string, Production>>>(ref reader, options);
                var table = new HashTable<string, Production>(items?.Count ?? 0);

                if (items != null)
                {
                    foreach (var item in items)
                    {
                        table.Add(item.Key, item.Value);
                    }
                }

                return table;
            }

            public override void Write(Utf8JsonWriter writer, HashTable<string, Production> value, JsonSerializerOptions options)
            {
                JsonSerializer.Serialize(writer, value.ToList(), options);
            }
        }

        private class ProductionConverter : JsonConverter<Production>
        {
            public override Production Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
            {
                using (var doc = JsonDocument.ParseValue(ref reader))
                {
                    var root = doc.RootElement;
                    var type = root.GetProperty("Type").GetString();
                    var countProd = root.GetProperty("CountProd").GetInt32();

                    if (root.TryGetProperty("$type", out var typeProp))
                    {
                        return typeProp.GetString() switch
                        {
                            "Factory" => new Factory(type, countProd, root.GetProperty("CountDepartments").GetInt32()),
                            "Department" => new Department(type, countProd,
                                root.GetProperty("CountDepartments").GetInt32(),
                                root.GetProperty("TypeDepartment").GetString()),
                            "WorkShop" => new WorkShop(type, countProd,
                                root.GetProperty("CountDepartments").GetInt32(),
                                root.GetProperty("TypeDepartment").GetString(),
                                root.GetProperty("CountWorker").GetInt32()),
                            _ => new Production(type, countProd)
                        };
                    }

                    return new Production(type, countProd);
                }
            }

            public override void Write(Utf8JsonWriter writer, Production value, JsonSerializerOptions options)
            {
                writer.WriteStartObject();
                writer.WriteString("$type", value.GetType().Name);
                writer.WriteString("Type", value.Type);
                writer.WriteNumber("CountProd", value.CountProd);

                switch (value)
                {
                    case WorkShop ws:
                        writer.WriteNumber("CountDepartments", ws.CountDepartments);
                        writer.WriteString("TypeDepartment", ws.TypeDepartment);
                        writer.WriteNumber("CountWorker", ws.CountWorker);
                        break;
                    case Department dep:
                        writer.WriteNumber("CountDepartments", dep.CountDepartments);
                        writer.WriteString("TypeDepartment", dep.TypeDepartment);
                        break;
                    case Factory fac:
                        writer.WriteNumber("CountDepartments", fac.CountDepartments);
                        break;
                }

                writer.WriteEndObject();
            }
        }
    }
}
